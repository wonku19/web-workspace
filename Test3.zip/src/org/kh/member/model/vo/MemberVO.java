package org.kh.member.model.vo;

public class MemberVO {

}
